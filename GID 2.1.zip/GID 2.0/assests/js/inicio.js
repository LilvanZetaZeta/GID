document.addEventListener('DOMContentLoaded', () => {
    const formLogin = document.getElementById('formLogin');
    const mensajeLogin = document.createElement('div');
    mensajeLogin.style.marginTop = "10px";
    formLogin.appendChild(mensajeLogin);

    formLogin.addEventListener('submit', function(e) {
        e.preventDefault();

        const correo = formLogin.correo.value.trim();
        const contraseña = formLogin.contraseña.value;

        // Obtener usuarios del localStorage
        const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

        // Buscar usuario que coincida con correo y contraseña
        const usuario = usuarios.find(u => u.correo === correo && u.contraseña === contraseña);

        if (usuario) {
            mensajeLogin.textContent = "Inicio de sesión exitoso";
            mensajeLogin.style.color = "green";

            setTimeout(() => {
                window.location.href = "../../index.html"; // Cambia por tu página de inicio
            }, 1000);
        } else {
            mensajeLogin.textContent = "Usuario o contraseña incorrecta";
            mensajeLogin.style.color = "red";
        }
    });
});