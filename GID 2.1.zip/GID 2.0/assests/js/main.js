// Función para agregar al carrito con límite
function addToCart(name, price, img) {
  const maxStock = 4; // límite de unidades disponibles
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Preguntar cuántas unidades quiere
  let cantidad = prompt(`¿Cuántas unidades de "${name}" deseas agregar? (Disponibles en Stock: ${maxStock})`, "1");
  cantidad = parseInt(cantidad);

  if (isNaN(cantidad) || cantidad <= 0) {
    alert("Cantidad no válida ❌");
    return;
  }

  if (cantidad > maxStock) {
    alert(`Solo hay ${maxStock} unidades disponibles de "${name}" 🚫`);
    return;
  }

  const existing = cart.find(item => item.name === name);

  if (existing) {
    if (existing.quantity + cantidad > maxStock) {
      alert(`Ya tienes ${existing.quantity} en el carrito. Solo puedes agregar ${maxStock - existing.quantity} más.`);
      return;
    }
    existing.quantity += cantidad;
  } else {
    cart.push({ name, price, quantity: cantidad, img });
  }

  localStorage.setItem("cart", JSON.stringify(cart));
  alert(`${cantidad} ${name}(s) agregado(s) al carrito 🛒`);
}

// Activar todos los botones de "agregar al carrito"
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".add-cart").forEach(button => {
    button.addEventListener("click", () => {
      const name = button.getAttribute("data-name");
      const price = parseInt(button.getAttribute("data-price"));
      const img = button.getAttribute("data-img");
      addToCart(name, price, img);
    });
  });
});
