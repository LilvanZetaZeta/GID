document.addEventListener('DOMContentLoaded', () => {
    const formRegistro = document.getElementById('formRegistro');
    const mensajeRegistro = document.createElement('div');
    mensajeRegistro.style.marginTop = "10px";
    formRegistro.appendChild(mensajeRegistro);

    formRegistro.addEventListener('submit', function(e) {
        e.preventDefault();

        const correo = formRegistro.correo.value.trim();
        const contraseña = formRegistro.contraseña.value;
        const confirmar = formRegistro.confirmar.value;

        if (!(correo.endsWith("@duocuc.cl") || correo.endsWith("@profesor.duocuc.cl"))) {
            mensajeRegistro.textContent = "Solo se permiten correos @duocuc.cl o @profesor.duocuc.cl";
            mensajeRegistro.style.color = "red";
            return;
        }

        if (contraseña !== confirmar) {
            mensajeRegistro.textContent = "Las contraseñas no coinciden";
            mensajeRegistro.style.color = "red";
            return;
        }

        let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

        if (usuarios.some(u => u.correo === correo)) {
            mensajeRegistro.textContent = "Este correo ya está registrado";
            mensajeRegistro.style.color = "red";
            return;
        }

        usuarios.push({ correo, contraseña });
        localStorage.setItem("usuarios", JSON.stringify(usuarios));

        mensajeRegistro.textContent = "Registro exitoso";
        mensajeRegistro.style.color = "green";
            setTimeout(() => {
                window.location.href = "inicio.html"; // Cambia por tu página de inicio
            }, 1000);        

        formRegistro.reset();
    });
});