// Función para agregar al carrito con límite
function addToCart(name, price, img) {
  const maxStock = 4; // límite de unidades disponibles
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Preguntar cuántas unidades quiere
  let cantidad = prompt(`¿Cuántas unidades de "${name}" deseas agregar? (Disponibles en Stock: ${maxStock})`, "1");
  cantidad = parseInt(cantidad);

  if (isNaN(cantidad) || cantidad <= 0) {
    alert("Cantidad no válida ❌");
    return;
  }

  if (cantidad > maxStock) {
    alert(`Solo hay ${maxStock} unidades disponibles de "${name}" 🚫`);
    return;
  }

  const existing = cart.find(item => item.name === name);

  if (existing) {
    if (existing.quantity + cantidad > maxStock) {
      alert(`Ya tienes ${existing.quantity} en el carrito. Solo puedes agregar ${maxStock - existing.quantity} más.`);
      return;
    }
    existing.quantity += cantidad;
  } else {
    cart.push({ name, price, quantity: cantidad, img });
  }

  localStorage.setItem("cart", JSON.stringify(cart));
  alert(`${cantidad} ${name}(s) agregado(s) al carrito 🛒`);
}

// Activar todos los botones de "agregar al carrito"
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".add-cart").forEach(button => {
    button.addEventListener("click", () => {
      const name = button.getAttribute("data-name");
      const price = parseInt(button.getAttribute("data-price"));
      const img = button.getAttribute("data-img");
      addToCart(name, price, img);
    });
  });
});

// Script para el modal

document.addEventListener("DOMContentLoaded", () => {
  const modal = document.getElementById("modal");
  const modalImg = document.getElementById("modal-img");
  const modalTitle = document.getElementById("modal-title");
  const modalPrice = document.getElementById("modal-price");
  const modalAddCart = document.getElementById("modal-add-cart");
  const closeBtn = document.querySelector(".close");

  // Abrir modal al hacer click en cualquier btn-visualizar
  document.querySelectorAll(".btn-visualizar").forEach(btn => {
    btn.addEventListener("click", () => {
      const name = btn.dataset.name;
      const price = btn.dataset.price;
      const img = btn.dataset.img;

      // Rellenar modal
      modalTitle.textContent = name;
      modalPrice.textContent = "$" + price;
      modalImg.src = img;

      // Guardar datos en el botón add-cart del modal
      modalAddCart.dataset.name = name;
      modalAddCart.dataset.price = price;
      modalAddCart.dataset.img = img;

      // Mostrar modal
      modal.style.display = "flex";
    });
  });

  // Cerrar modal con la X
  closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
  });

  // Cerrar modal al hacer click fuera
  window.addEventListener("click", (e) => {
    if (e.target.id === "modal") {
      modal.style.display = "none";
    }
  });

  // Botón add-cart dentro del modal
  modalAddCart.addEventListener("click", () => {
    addToCart(modalAddCart.dataset.name, modalAddCart.dataset.price, modalAddCart.dataset.img);
  });
});

