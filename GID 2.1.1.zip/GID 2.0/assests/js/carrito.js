// Cargar carrito desde localStorage
let cart = JSON.parse(localStorage.getItem("cart")) || [];

const cartItemsContainer = document.getElementById("cart-items");
const cartTotalSpan = document.getElementById("cart-total");

// Renderizar carrito
function renderCart() {
  cartItemsContainer.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td><img src="${item.img}" alt="${item.name}" width="50"> ${item.name}</td>
      <td>$${item.price.toLocaleString()}</td>
      <td>${item.quantity}</td>
      <td>$${(item.price * item.quantity).toLocaleString()}</td>
      <td><button class="remove-btn" onclick="removeItem(${index})">❌</button></td>
    `;
    cartItemsContainer.appendChild(row);
    total += item.price * item.quantity;
  });

  cartTotalSpan.innerText = total.toLocaleString();
}

// Eliminar producto
function removeItem(index) {
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

// Finalizar compra
document.getElementById("checkout-btn").addEventListener("click", () => {
  if (cart.length === 0) {
    alert("No hay productos en el carrito.");
    return;
  }
  alert("Compra realizada con éxito! ✅");
  cart = [];
  localStorage.removeItem("cart");
  window.location.href = "../../index.html"; 
  renderCart();
});

// Renderizar carrito al cargar la página
document.addEventListener("DOMContentLoaded", renderCart);
